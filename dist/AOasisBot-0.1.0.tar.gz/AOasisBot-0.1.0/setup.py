# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['aoasisbot']

package_data = \
{'': ['*']}

install_requires = \
['PyMongo>=3.10.1,<4.0.0',
 'discord.py>=1.3.4,<2.0.0',
 'mongoengine>=0.20.0,<0.21.0',
 'requests-futures>=1.0.0,<2.0.0']

setup_kwargs = {
    'name': 'aoasisbot',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'ntsmoura',
    'author_email': 'natloc215@hotmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.5.3,<4.0.0',
}


setup(**setup_kwargs)

import mongoengine

class User(mongoengine.EmbeddedDocument):
    name = mongoengine.StringField()
    api_key = mongoengine.StringField()